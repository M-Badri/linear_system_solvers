#ifdef _IMPURE_
#define _PURE_
#define _ELEMENTAL_
#else
#define _PURE_ pure
#define _ELEMENTAL_ elemental
#endif
